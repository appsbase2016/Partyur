//interface Navigator {
//    app: any;
//}
 
declare var facebookConnectPlugin: any;

