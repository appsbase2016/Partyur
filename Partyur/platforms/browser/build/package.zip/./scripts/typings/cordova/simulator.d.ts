interface Navigator {
    simulator?: boolean;
}