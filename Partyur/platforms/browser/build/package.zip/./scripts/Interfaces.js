define(["require", "exports"], function (require, exports) {
    var facebookConnectPlugin;
});
