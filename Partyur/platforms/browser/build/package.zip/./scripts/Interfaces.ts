export interface Location {
    _id: number;
    name: string;
    loc: { lon: number; lat: number; };
}


var facebookConnectPlugin: any;
